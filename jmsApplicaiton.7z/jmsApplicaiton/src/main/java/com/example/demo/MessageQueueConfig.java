package com.example.demo;
import com.ibm.mq.jms.MQQueueConnectionFactory;
import com.ibm.msg.client.wmq.WMQConstants;
import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.jms.config.DefaultJmsListenerContainerFactory;
import org.springframework.jms.config.JmsListenerContainerFactory;
import org.springframework.jms.connection.UserCredentialsConnectionFactoryAdapter;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.util.backoff.FixedBackOff;

@Configuration
@EnableJms
@Getter
@Setter
public class MessageQueueConfig {

  @Value("${ibm.mq.queueManager}")
  String queueManager;

  @Value("${ibm.mq.channel}")
  String channel;

  @Value("${ibm.mq.hostName}")
  String hostName;

  @Value("${ibm.mq.port}")
  int port;

  @Value("${ibm.mq.user}")
  String username;

  @Value("${mq.timeout}")
  long timeout;

  @Value("${mq.maxAttempts}")
  int maxAttempts;

  @Value("${spring.application.name}")
  String applicationName;


  @Bean
  public MQQueueConnectionFactory mqQueueConnectionFactory() throws Exception {

    MQQueueConnectionFactory mqQueueConnectionFactory = new MQQueueConnectionFactory();
    mqQueueConnectionFactory.setQueueManager(queueManager);
    mqQueueConnectionFactory.setHostName(hostName);
    mqQueueConnectionFactory.setPort(port);
    mqQueueConnectionFactory.setChannel(channel);
    mqQueueConnectionFactory.setTransportType(WMQConstants.WMQ_CM_CLIENT);

    // You could still override some of Boot's default if necessary.
    UserCredentialsConnectionFactoryAdapter mqCredential = new UserCredentialsConnectionFactoryAdapter();
    mqCredential.setUsername(username);
    mqCredential.setTargetConnectionFactory(mqQueueConnectionFactory);
    mqQueueConnectionFactory.setAppName("applicationName");

    return mqQueueConnectionFactory;
  }

  @Bean
  public JmsTemplate defaultJsmTemplate(MQQueueConnectionFactory mqQueueConnectionFactory) {
    JmsTemplate jmsTemplate = new JmsTemplate();
    jmsTemplate.setConnectionFactory(mqQueueConnectionFactory);
    return jmsTemplate;
  }

  @Bean
  public JmsListenerContainerFactory<?> jmsListenerContainerFactory(
      MQQueueConnectionFactory mqQueueConnectionFactory) {

    DefaultJmsListenerContainerFactory jmsListenerContainerFactory = new DefaultJmsListenerContainerFactory();
    jmsListenerContainerFactory.setConnectionFactory(mqQueueConnectionFactory);
    jmsListenerContainerFactory.setPubSubDomain(false);
    FixedBackOff fixedBackOff = new FixedBackOff();
    fixedBackOff.setInterval(timeout);
    fixedBackOff.setMaxAttempts(maxAttempts);
    jmsListenerContainerFactory.setBackOff(fixedBackOff);
    jmsListenerContainerFactory.setErrorHandler(error -> {
      //TODO
      new Exception(error).printStackTrace();
    });
    return jmsListenerContainerFactory;
  }

}
