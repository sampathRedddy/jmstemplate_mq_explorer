package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.JmsException;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class jmsController {

	@Autowired
    private JmsTemplate jmsTemplate;
	
	@Value("${ibm.mq.out:AGHILDIY.TEST.Q}")
	  String queueManager;
	//@Value("${mq.emailQueue:IA.EMAIL.REQUEST.Q}")
	@GetMapping("send")
	String send(){
	    try{
	        jmsTemplate.convertAndSend(queueManager, "Hello World!");
	        System.out.println("succesfully posted message to queue");
	        return "OK";
	    }catch(JmsException ex){
	        ex.printStackTrace();
	        return "FAIL";
	    }
	}
	
	@GetMapping("recv")
	String recv(){
	    try{
	    	System.out.println("succesfully consumed message to queue");
	        return jmsTemplate.receiveAndConvert(queueManager).toString();
	    }catch(JmsException ex){
	        ex.printStackTrace();
	        return "FAIL";
	    }
	}
}
